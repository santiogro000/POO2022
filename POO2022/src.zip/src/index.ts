import { App } from './controller/app';

const app = App.getInstance();
app.run();

export default app;
