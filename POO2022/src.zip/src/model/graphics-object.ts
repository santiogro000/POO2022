export interface GraphicsObject {
    paint( 
        ctx: CanvasRenderingContext2D ): void;
}

